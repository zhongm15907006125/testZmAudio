package mu.phone.call.util;

/**
 * @author LiYejun
 * @date 2023/2/7
 */
public interface CallFileWatcherListener {

    void onCreate(String path);
}
